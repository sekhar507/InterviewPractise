package Q7_03_Jukebox;

public class Song {
	private String songName;
	public String toString() { return songName; }
}
