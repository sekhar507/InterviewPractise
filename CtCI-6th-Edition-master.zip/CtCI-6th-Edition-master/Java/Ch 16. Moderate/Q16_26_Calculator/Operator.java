package Q16_26_Calculator;

public enum Operator {
	ADD, SUBTRACT, MULTIPLY, DIVIDE, BLANK
}
