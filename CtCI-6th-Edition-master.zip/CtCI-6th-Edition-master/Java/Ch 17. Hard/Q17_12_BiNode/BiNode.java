package Q17_12_BiNode;

public class BiNode {
	public BiNode node1;
	public BiNode node2;
	public int data; 
	public BiNode(int d) {
		data = d;
	}
}
