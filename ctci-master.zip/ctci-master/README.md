ctci
====

Solutions for "Cracking the Coding Interview v5"

Adding equivalent solutions in Objective-C
Adding my own solutions
