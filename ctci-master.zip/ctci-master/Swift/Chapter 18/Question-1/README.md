## Question 18.1
```
Write a function that adds two numbers. You should not use + or any arithmetic op- erators.
```