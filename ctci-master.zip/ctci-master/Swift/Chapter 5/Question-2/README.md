 ## Question 5_2
 ```
 Youaregiven two 32-bit numbers,N andM, andtwobitpositions, i andj. Write a method to insert Minto Nsuch that Mstarts at bit j and ends at bit i. Youcan assume that the bits j through i have enough space to fit all ofM. That is,ifM= 10011, you can assume that there are at least 5 bits between j and i. You would not, for example,havej-3 andi=2,becauseMcouldnotfully fitbetweenbit3andbit2.

EXAMPLE:
Input:N=16000000000, M=10011, i =2, j =6 Output: N = 10001001100

```


