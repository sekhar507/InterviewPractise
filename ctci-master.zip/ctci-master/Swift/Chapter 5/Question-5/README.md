 ## Question 5_5
 ```
 Write a function to determine the number of bits required to convert integer A to integer B
Input: 31, 14 Output: 2

```

###Algorithm:
Step 1:
```
XOR the two inputs and get the result 
```

Step 2:
```
Count the number of 1's in the number. This is the result
```
