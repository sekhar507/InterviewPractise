## INTRODUCTION
------------

Cracking the Coding Interview with Apple Swift. 
Buy the book and support the author. [Cracking the Coding Interview](http://www.amazon.com/dp/098478280X/)

## Respect the stack
If you want to contribute, respect these rules :
- One folder for each chapter called `Chapter X`.
- Create One playground file calle `Chapter X`.
- Implement each question under a `// MARK: `
- Use extension for each question when this is possible
- Implement a simple exemple below each question

## TODO
----
- Chapter 2 - WIP
- Chapter 3
- Chapter 4
- Chapter 6
- Chapter 7
- Chapter 8
- Chapter 9
- Chapter 10
- Chapter 11
- Chapter 12
- Chapter 13
- Chapter 14
- Chapter 15
- Chapter 16
- Chapter 17
- Chapter 18 - WIP


