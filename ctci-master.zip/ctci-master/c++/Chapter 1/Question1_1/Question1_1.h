#ifndef __Question_1_1_h__
#define __Question_1_1_h__

#include <string>

using std::string;

class Question1_1 
{
public:
    int run();
    bool isUniqueChars(const string& str);
    bool isUniqueChars2(const string& str);
    string result(bool value);
}; 

#endif // __Question_1_1_h__