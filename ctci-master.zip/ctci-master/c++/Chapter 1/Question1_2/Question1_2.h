#ifndef __Question_1_2_h__
#define __Question_1_2_h__

class Question1_2 
{
public:
    int run();
    void reverse(char* str);
}; 

#endif // __Question_1_2_h__