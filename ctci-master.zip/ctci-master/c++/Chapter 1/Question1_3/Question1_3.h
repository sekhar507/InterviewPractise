#ifndef __Question_1_3_h__
#define __Question_1_3_h__

#include <string>

using std::string;

class Question1_3 
{
public:
    int run();
    bool permutation(const string& a, const string& b);
    string result(bool value);
}; 



#endif // __Question_1_3_h__