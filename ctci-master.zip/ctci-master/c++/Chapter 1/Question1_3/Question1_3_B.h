#ifndef __Question_1_3_B_h__
#define __Question_1_3_B_h__

#include <string>

using std::string;

class Question1_3_B 
{
public:
    int run();
    bool permutation(const string& a, const string& b);
    string result(bool value);
}; 



#endif // __Question_1_3_B_h__