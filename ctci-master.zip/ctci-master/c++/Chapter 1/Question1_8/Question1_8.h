#ifndef __Question_1_8_h__
#define __Question_1_8_h__

#include <string>

using std::string;

class Question1_8 
{
public:
    string result(bool value);
    bool isRotation(const string& s1, const string& s2);
    int run();
};

#endif // __Question_1_8_h__