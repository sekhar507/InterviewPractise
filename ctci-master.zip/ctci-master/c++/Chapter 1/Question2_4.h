#ifndef __Question_2_4_h__
#define __Question_2_4_h__

#include <string>

using std::string;

class Question2_4
{
public:
    int run();
};

#endif // __Question_2_4_h__