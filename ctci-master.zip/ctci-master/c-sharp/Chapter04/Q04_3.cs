﻿
using ctci.Contracts;

namespace Chapter04
{
    public class Q04_3 : IQuestion
    {
        // Please see first part of Run in Q04_2 and CreateMinimalBst implementation
        public void Run()
        {}
    }
}
