﻿
using System;
using System.Collections.Generic;
using System.Text;

using ctci.Contracts;
using ctci.Library;

namespace Chapter18
{
    public class Q18_11 : IQuestion
    {
        public void Run()
        {}
    }
}
