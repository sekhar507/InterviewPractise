library binode;

class BiNode {
  BiNode node1;
  BiNode node2;
  int data;
  BiNode(this.data);
}

