library SquareCell;

class SquareCell {
  int zerosRight = 0;
  int zerosBelow = 0;
  SquareCell(this.zerosRight, this.zerosBelow);
}

