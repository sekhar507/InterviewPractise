library Subsquare;

class Subsquare {
  int row, column, size;
  Subsquare(this.row, this.column, this.size);
  String toString() => "($row, $column, $size)";
}

