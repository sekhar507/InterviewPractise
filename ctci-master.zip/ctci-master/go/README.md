Cracking The Coding Interview
=============================

This repository contains the solutions for 'Cracking The Coding Interview' book problems in GO

###Contributor

* Dinesh Appavoo ([@DineshAppavoo](https://twitter.com/DineshAppavoo))
